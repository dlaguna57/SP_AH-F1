package org.F1.Mun2024;

public class Circuito {
}
