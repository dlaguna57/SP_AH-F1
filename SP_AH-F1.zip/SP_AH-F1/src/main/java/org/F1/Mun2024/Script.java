package org.F1.Mun2024;

public class Script extends Circuito{

}
